#include "hello.h"

int
main(int argc, const char **argv) {
    printHello("Kenta");
    return 0;
}
