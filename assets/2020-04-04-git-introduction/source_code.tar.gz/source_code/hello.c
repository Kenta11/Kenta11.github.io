#include "hello.h"

#include <stdio.h>

void printHello(const char *name) {
    printf("Hello, %s!\n", name);
}
