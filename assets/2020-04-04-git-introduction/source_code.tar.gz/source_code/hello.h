// Copyright (c) Kenta Arai
#ifndef __HELLO_H__
#define __HELLO_H__

void printHello(const char *name);

#endif // __HELLO_H__
